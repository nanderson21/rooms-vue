import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { ViewTransitionsPlugin, startViewTransition } from 'vue-view-transitions'
import App from './App.vue'
import CollectionView from './views/CollectionView.vue'
import CollectionItemDetail from './views/CollectionItemDetail.vue'
import './assets/main.css'

// Ensure View Transitions API polyfill is available
if (!document.startViewTransition) {
  console.warn('View Transitions API is not supported in this browser. Transitions will be degraded.')
}

const routes = [
  { path: '/', component: CollectionView },
  { path: '/collection/:id', component: CollectionView },
  { path: '/collection/:id/item/:itemId', component: CollectionItemDetail },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// Apply view transitions for all navigation

router.beforeEach(async (to, from) => {
  if (document.startViewTransition) {
    try {
      const viewTransition = startViewTransition()
      await viewTransition.captured
    } catch (error) {
      console.error('Error during view transition:', error)
    }
  }
})

const app = createApp(App)
app.use(router)
app.use(ViewTransitionsPlugin())
app.mount('#app')