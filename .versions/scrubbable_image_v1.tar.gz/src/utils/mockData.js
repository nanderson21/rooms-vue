// Mock data for collections and media items
// Example sprite URL for video scrubbing (5x10 grid of frames)
const exampleSpriteUrl = 'https://i.imgur.com/qX5VT3S.jpg'; // Sample sprite sheet

export const collections = [
  {
    id: 'nab-demo',
    title: 'NAB 2025 Demo',
    description: 'Collection of NAB 2025 demo materials',
    thumbnail: 'https://placehold.co/600x400',
    totalSize: '2.3 GB',
    status: 'active',
    statusText: 'Active',
  }
];

// Mock media items within the collection
export const mediaItems = [
  {
    id: '1',
    projectId: 'nab-demo',
    title: 'Intro Video',
    description: 'Introduction to the NAB 2025 Demo',
    thumbnail: 'https://placehold.co/600x400',
    spriteUrl: exampleSpriteUrl,
    previewVideo: 'https://vjs.zencdn.net/v/oceans.mp4',
    mimetype: 'video/mp4',
    filetype: 'video',
    filesize: '52.3 MB',
    duration: '0:32',
    width: 1920,
    height: 1080,
    createdDate: '2025-03-15',
    modifiedDate: '2025-03-18',
  },
  {
    id: '2',
    projectId: 'nab-demo',
    title: 'Product Overview',
    description: 'Overview of the new product line',
    thumbnail: 'https://placehold.co/600x400',
    spriteUrl: exampleSpriteUrl,
    previewVideo: 'https://vjs.zencdn.net/v/oceans.mp4',
    mimetype: 'video/mp4',
    filetype: 'video',
    filesize: '78.6 MB',
    duration: '1:15',
    width: 1920,
    height: 1080,
    createdDate: '2025-03-16',
    modifiedDate: '2025-03-18',
  },
  {
    id: '3',
    projectId: 'nab-demo',
    title: 'Feature Highlights',
    description: 'Highlights of key features',
    thumbnail: 'https://placehold.co/600x400',
    spriteUrl: exampleSpriteUrl,
    previewVideo: 'https://vjs.zencdn.net/v/oceans.mp4',
    mimetype: 'video/mp4',
    filetype: 'video',
    filesize: '64.2 MB',
    duration: '0:45',
    width: 1920,
    height: 1080,
    createdDate: '2025-03-17',
    modifiedDate: '2025-03-18',
  },
  {
    id: '4',
    projectId: 'nab-demo',
    title: 'Presentation Slides',
    description: 'Presentation slides for the NAB 2025 Demo',
    thumbnail: 'https://placehold.co/600x400',
    mimetype: 'application/pdf',
    filetype: 'pdf',
    filesize: '3.2 MB',
    createdDate: '2025-03-18',
    modifiedDate: '2025-03-18',
  },
  {
    id: '5',
    projectId: 'nab-demo',
    title: 'Demo Audio',
    description: 'Audio track for the NAB 2025 Demo',
    thumbnail: 'https://placehold.co/600x400',
    mimetype: 'audio/mp3',
    filetype: 'audio',
    filesize: '8.7 MB',
    duration: '3:22',
    createdDate: '2025-03-14',
    modifiedDate: '2025-03-18',
  },
  {
    id: '6',
    projectId: 'nab-demo',
    title: 'Booth Photo',
    description: 'Photo of the NAB 2025 booth',
    thumbnail: 'https://placehold.co/600x400',
    mimetype: 'image/jpeg',
    filetype: 'image',
    filesize: '1.5 MB',
    width: 3000,
    height: 2000,
    createdDate: '2025-03-19',
    modifiedDate: '2025-03-19',
  }
];

// Mock comments for the media items
export const commentsStorage = {
  'nab-demo-1': [
    {
      id: 'comment-1',
      content: 'Great intro sequence!',
      timestamp: 5.5,
      author: {
        id: 'user-1',
        name: 'John Doe',
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
      },
      createdAt: '2025-03-19T10:23:45Z'
    },
    {
      id: 'comment-2',
      content: 'The logo animation needs to be a bit faster here',
      timestamp: 12.8,
      author: {
        id: 'user-2',
        name: 'Jane Smith',
        avatar: 'https://randomuser.me/api/portraits/women/44.jpg'
      },
      createdAt: '2025-03-19T10:25:12Z'
    }
  ],
  'nab-demo-2': [
    {
      id: 'comment-3',
      content: 'Can we highlight this feature more prominently?',
      timestamp: 20.5,
      author: {
        id: 'user-1',
        name: 'John Doe',
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
      },
      createdAt: '2025-03-19T11:15:22Z'
    }
  ]
};

// Helper function to get a collection by ID
export function getCollection(id) {
  return collections.find(collection => collection.id === id) || null;
}

// Helper function to get media items for a collection
export function getCollectionItems(collectionId) {
  return mediaItems.filter(item => item.projectId === collectionId);
}

// Helper function to get a media item by its ID and collection ID
export function getMediaItem(collectionId, itemId) {
  return mediaItems.find(item => item.projectId === collectionId && item.id === itemId) || null;
}

// Helper function to get comments for a media item
export function getComments(collectionId, itemId) {
  const storageKey = `${collectionId}-${itemId}`;
  return commentsStorage[storageKey] || [];
}

// Helper function to add a comment to a media item
export function addComment(collectionId, itemId, comment) {
  const storageKey = `${collectionId}-${itemId}`;
  if (!commentsStorage[storageKey]) {
    commentsStorage[storageKey] = [];
  }
  commentsStorage[storageKey].push(comment);
  return comment;
}