<template>
  <div class="app">
    <header class="header">
      <h1>Rooms Vue</h1>
    </header>
    <main>
      <router-view v-slot="{ Component }">
        <component :is="Component" />
      </router-view>
    </main>
  </div>
</template>

<script>
export default {
  name: 'App',
  mounted() {
    // Add meta tag for view transitions if not present
    if (!document.querySelector('meta[name="view-transition"]')) {
      const meta = document.createElement('meta');
      meta.name = 'view-transition';
      meta.content = 'same-origin';
      document.head.appendChild(meta);
    }
  }
}
</script>

<style>
.app {
  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu,
    Cantarell, 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin: 0;
  padding: 0;
}

.header {
  padding: 1rem;
  background-color: #f8f9fa;
  border-bottom: 1px solid #e9ecef;
}

main {
  min-height: calc(100vh - 80px);
  position: relative;
}

/* Core view transitions overrides */
::view-transition-group(image),
::view-transition-group(video-image) {
  height: 100% !important;
  width: 100% !important;
  overflow: hidden;
  contain: paint;
}
</style>